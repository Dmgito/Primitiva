Thank you for purchasing FUT Autobuyer. If you need any help, contact us on our website.

IF YOU DIDN'T DOWNLOAD THIS FILE FROM http://www.fifaautobuyer.co.uk/ THEN YOU MAY HAVE BEEN SCAMMED/DOWNLOADED A VIRUS! DOWNLOAD THE LATEST SAFE VERSION FROM OUR SITE!